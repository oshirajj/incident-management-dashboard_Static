const links=document.querySelectorAll('.sidebar a')
const pages=document.querySelectorAll('.page')
links.forEach(l=>l.onclick=()=>{
  links.forEach(x=>x.classList.remove('active'))
  pages.forEach(p=>p.classList.remove('active'))
  l.classList.add('active')
  const id=l.getAttribute('href').replace('#','')
  document.getElementById(id).classList.add('active')
})